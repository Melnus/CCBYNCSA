readme and LICENSE


_______________________________________________________________________________

please copy this sentences under line.


LICENSE

Permission for Use(this files,ALL MY VRM FILES)

[

-Attribution-NonCommercial-ShareAlike 4.0 Generic

 You can use this models on any services on the basis of CC BY-NC-SA 4.0.


-publicity

 Okay: use this models on non-commercial purpose

Never: use this models on commercial purpose (see below)


-privacy

 Okay: remodeling my models from this files, and attached this LICENSE

Never: remodeling (or creating a new) my models from this files, and NOT attached this LICENSE


-moral rights

 Okay: you can use this models as long as it is not contrary to any service of policy. (examples; violent acts or sextuality acts)

Never: deviant behavior to any service of policy (examples; hate speech or doing a troll)

]

this Models made by Melnus (Heihatchi Shirasuka)

don't forget to take care of her

Twitter: @Melnus_
Discord: Melnus#2688
https://xrmelnus.wixsite.com/melnus

If you have any questions, please contact me




CCBYNCSA means Creative Commons. 
https://creativecommons.org/licenses/by-nc-sa/4.0/
non-commercial use only.


commercial use examples;

/Sell my 3D Models/textures/psd files.
/Sell my 3D Models included with Your products(games etc)



please copy this sentences  above line.


_______________________________________________________________________________

read me

this is VRM Model for UniVRM0.5.1


*04/27/2019


